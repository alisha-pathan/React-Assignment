import { BrowserRouter, Route, Routes } from 'react-router-dom'
import './App.css'
import Home from './Home'
import Add from './Add'

function App() {
 
  return (
    <>
     <BrowserRouter>
     
      <Routes>
        <Route path='/' element = {<Home></Home>}></Route>
        <Route path='/add' element = {<Add></Add>}></Route>
      </Routes>
     </BrowserRouter>
    
    </>
  )
}

export default App
