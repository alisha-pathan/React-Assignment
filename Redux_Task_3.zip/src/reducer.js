import { createSlice } from "@reduxjs/toolkit";

let userSlice = createSlice({
    name : "user",
    initialState : [],
    reducers : {
        getuser : (state,action)=>{
            state.push(action.payload)
        }
    }
})

export const {getuser} = userSlice.actions;
export default userSlice.reducer;