import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { getuser } from './reducer';
import { Link } from 'react-router-dom';

function Home() {
  let [userdetails, setuserdetails] = useState([]);
  let dispatch = useDispatch();

  // let dispatchdata = () => {
  //   dispatch(getuser(userdetails))
  // }

  useEffect(() => {
    fetch("http://localhost:4000/users")
      .then((res) => { return res.json() })
      .then((data) => {
        setuserdetails(data);
        dispatch(getuser(userdetails))
      })
  }, [])


  return (
    <>
    <Link to="/add" > add </Link>
      <table border={2} width={"800px"}>
        <thead>
          <tr>
            <th>Id</th>
            <th>Name</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {
            userdetails.map((user) => (
              <tr key={user.id}>
                <td>{user.id}</td>
                <td>{user.name}</td>
                <td>
                  <button>Edit</button>
                  <button>Delet</button>
                </td>
              </tr>
            ))
          }

        </tbody>
      </table>
    </>
  )
}

export default Home
