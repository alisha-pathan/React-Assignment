import React, { useEffect, useState } from 'react'
import { useSelector } from 'react-redux';

function Add() {
    // let [userdata, setuserdata] = useState([])
  let userdata =  useSelector(state => state.userdata)
    let [name, setname] = useState("");

    // useEffect(() => {
    //     fetch("http://localhost:4000/users")
    //         .then((res) => { return res.json() })
    //         .then((data) => {
    //             setuserdata(data)
                
    //         })
    // }, [])

    console.log(userdata);
    
    const handlesub = (e) => {
        e.preventDefault();
    }


    return (
        <div>
            <form onSubmit={handlesub}>
                <label htmlFor="name">name</label> <input type="text" value={name} onChange={(e) => { setname(e.target.value) }} />

                <input type="submit" value="Add" />
            </form>
        </div>
    )
}

export default Add
