// Task:
// • Create a React component that renders the following JSX elements:
// • A heading with the text "Welcome to JSX".
// • A paragraph explaining JSX with dynamic data (use curly braces to 
// insertvariables).

//   
function Test() {
  let text = "Welcome To JSX"
  function change() {
    let h1 = document.querySelector('h1')
    let a = "Welcome to ";

    let chn = ["JS", "JSX", "React", "WD"]
    let i = 0;
    setInterval(() => {
      h1.innerHTML = a + chn[i];
      i++;

      if (i === chn.length) {
        i = 0;
      }
    }, 1000);
  }

  let obj = {
    textAlign: "center",
  }

  let btn = {
    display: "block",
    width: "200px",
    margin: "auto",
    backgroundColor: "lightgreen",
    border: "2px solid black",
    fontSize: "20px",
    padding: "5px"
  }

  let para = "JSX, or JavaScript XML, is a syntax extension for JavaScript commonly used with React, a popular JavaScript library for building user interfaces. JSX allows developers to write HTML-like code within JavaScript, making it easier to create and visualize the structure of the UI components.";
  return (
    <>
      <h1 style={{ ...obj, "color": "red" }}>{text}</h1>
      <p style={{ ...obj, "color": "gray" }}>{para}</p>
      <button style={{ ...obj, ...btn }} onClick={change}>click</button>
    </>
  )
}
export default Test;