import React3 from "./React3";
import "./App.css"

function App() {
  return (
    <>
      <React3></React3>
    </>
  );
}

export default App;
