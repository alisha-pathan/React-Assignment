// Task:
// • Set up a new React.js project using create-react-app.
// • Create a basic component that displays "Hello, React!" on the web page.

import './App.css';

function App() {
  return (
   <>
      <h1>Hello React!</h1>
   </>
  );
}

export default App;
