import React from 'react'
import Stylecomponenets from './Stylecomponenets'

function About() {
  return (
    <div>
      <Stylecomponenets></Stylecomponenets>
    </div>
  )
}

export default About
